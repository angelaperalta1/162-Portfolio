import unittest
from ChessVar import *
#

class TestPawn(unittest.TestCase):
    """
    pawn unit test
    """
    def test_allowed_moves(self):
        """
        test column mapping portion
        :return:
        """

        game = ChessVar()


